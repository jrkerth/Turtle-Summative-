
/**
 * Exploring the String class and its methods.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class StringExplorer
{
    public static void main(String[] args)
    {
        String river = new String("Mississippi");
        System.out.println(river);
        System.out.println("hello world");
        
        river.replace("i", "x");
        System.out.println(river);
        
        /*
         * The replace method returns a reference to a new string object.
         *   It does not change the string object on which it is invoked.
         *   The string class by design has no mutator methods. It is not
         *     possible to change a string object.
         * 
         * Strings are immutable.
         */
        String riverX = river.replace("i", "x");
        System.out.println(riverX);
        
    }
}
