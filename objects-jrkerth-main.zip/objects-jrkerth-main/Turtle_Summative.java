import java.awt.Color;
import java.util.Random;
public class Turtle_Summative
{
    public static void main(String[] args)
    {
        World Large = new World(2500, 1000);
        Random turnroller = new Random();
        Turtle Bob_Ross = new Turtle(1250,500,Large);
        Turtle Da_Vinci = new Turtle(1250,500,Large);
        Bob_Ross.setPenWidth(5);
        Da_Vinci.setPenWidth(5);
        Bob_Ross.penUp();
        Da_Vinci.penUp();
        Da_Vinci.forward(50);
        Bob_Ross.turnRight();
        Da_Vinci.turnRight();
        Bob_Ross.penDown();
        Da_Vinci.penDown();
        Da_Vinci.setPenColor(Color.DARK_GRAY);
        Bob_Ross.setPenColor(Color.YELLOW);
        // Reference for while loop in java https://www.w3schools.com/java/java_while_loop.asp
        // Reference for if statements in java https://docs.oracle.com/javase/tutorial/java/nutsandbolts/if.html
        int degrees_turned = 0;
        int runs = 0;
        while (runs != 10)
        
        {
        runs += 1;
        while (degrees_turned < 90)
        {
         int randturn = turnroller.nextInt(180);
         int negative1 = turnroller.nextInt(2);
         if (negative1 == 0) {
             randturn = randturn * -1;
         }
         Bob_Ross.turn(randturn);
         int randturn2 = turnroller.nextInt(90);
         int negative2 = turnroller.nextInt(2);
         if (negative2 == 0) {
             randturn2 = randturn2 * -1;
         }
         Da_Vinci.turn(randturn2);   
         int randcolor = turnroller.nextInt(13);
        if(randcolor ==  0){
         Bob_Ross.setPenColor(Color.black);
        }
        else if(randcolor == 1){
          Bob_Ross.setPenColor(Color.blue);   
        }
        else if(randcolor == 2){
          Bob_Ross.setPenColor(Color.cyan);
        }        
        else if(randcolor == 3){
          Bob_Ross.setPenColor(Color.darkGray);
        }
        else if(randcolor == 4){
          Bob_Ross.setPenColor(Color.gray);   
        }
        else if(randcolor == 5){
          Bob_Ross.setPenColor(Color.green);   
        }
        else if(randcolor == 6){
          Bob_Ross.setPenColor(Color.lightGray);   
        }
        else if(randcolor == 7){
          Bob_Ross.setPenColor(Color.magenta);   
        }
        else if(randcolor == 8){
          Bob_Ross.setPenColor(Color.orange);   
        }
        else if(randcolor == 9){
          Bob_Ross.setPenColor(Color.pink);   
        }
        else if(randcolor == 10){
          Bob_Ross.setPenColor(Color.red);   
        }
        else if(randcolor == 11){
          Bob_Ross.setPenColor(Color.white);   
        }
        else if(randcolor == 12){
          Bob_Ross.setPenColor(Color.yellow);   
        }
        
        
        
         int randcolor2 = turnroller.nextInt(13);
        if(randcolor2 ==  0){
         Da_Vinci.setPenColor(Color.black);
        }
        else if(randcolor2 == 1){
          Da_Vinci.setPenColor(Color.blue);   
        }
        else if(randcolor2 == 2){
          Da_Vinci.setPenColor(Color.cyan);
        }        
        else if(randcolor2 == 3){
          Da_Vinci.setPenColor(Color.darkGray);
        }
        else if(randcolor2 == 4){
          Da_Vinci.setPenColor(Color.gray);   
        }
        else if(randcolor2 == 5){
          Da_Vinci.setPenColor(Color.green);   
        }
        else if(randcolor2 == 6){
          Da_Vinci.setPenColor(Color.lightGray);   
        }
        else if(randcolor2 == 7){
          Da_Vinci.setPenColor(Color.magenta);   
        }
        else if(randcolor2 == 8){
          Da_Vinci.setPenColor(Color.orange);   
        }
        else if(randcolor2 == 9){
          Da_Vinci.setPenColor(Color.pink);   
        }
        else if(randcolor2 == 10){
          Da_Vinci.setPenColor(Color.red);   
        }
        else if(randcolor2 == 11){
          Da_Vinci.setPenColor(Color.white);   
        }
        else if(randcolor2 == 12){
          Da_Vinci.setPenColor(Color.yellow);   
        }
         int randforward = turnroller.nextInt(61);
         int randforward2 = turnroller.nextInt(61);
         Bob_Ross.forward(randforward);
         Da_Vinci.forward(randforward2); 
         degrees_turned += 1;
         if (Da_Vinci.getXPos() >600 )
         {
             Da_Vinci.moveTo(1250,500);
         }
         else if (Da_Vinci.getXPos() < -600 )
         {
             Da_Vinci.moveTo(1250,500);
         }
         if (Bob_Ross.getXPos() >2000 )
         {
             Bob_Ross.moveTo(1850,500);
         }
         else if (Bob_Ross.getXPos() < -1500 )
         {
             Bob_Ross.moveTo(1250,500);
         }
         if (Da_Vinci.getYPos() >400 )
         {
             Da_Vinci.moveTo(1250,500);
         }
         else if (Da_Vinci.getYPos() < -400 )
         {
             Da_Vinci.moveTo(1250,500);
         }
         if (Bob_Ross.getYPos() >600 )
         {
             Bob_Ross.moveTo(1250,500);
         }
         else if (Bob_Ross.getYPos() < -1000 )
         {
             Bob_Ross.moveTo(1250,500);
         }
        }
        degrees_turned = 0;
    }
        /*
        
        while (degrees_turned < 190)
        {
         Bob_Ross.turn(1);
         Da_Vinci.turn(1);   
         Bob_Ross.forward(1);
         Da_Vinci.forward(1); 
         degrees_turned += 1;
        }
        Bob_Ross.forward(500);
        Da_Vinci.forward(500);
        
        */
    }
    
    
    
}