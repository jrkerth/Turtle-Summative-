import java.awt.Color;

public class TurtleLab
{
    public static void main(String[] args)
    {
        
    }
}
