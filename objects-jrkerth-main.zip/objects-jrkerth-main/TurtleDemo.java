import java.awt.Color;
public class TurtleDemo
{
    public static void main(String[] args)
    {
        
        World ocean = new World();
        Turtle crush = new Turtle(ocean);
        crush.setPenColor(Color.ORANGE);
        crush.penDown();
        /*
        crush.forward(50);
        crush.penUp();
        crush.setPenColor(Color.GREEN);
        crush.forward(20);
        crush.penDown();
        crush.setHeight(50);
        crush.setWidth(200);
        crush.forward(12);
         */
        
        /*
         * When invoking methods, we use the dot operator '.'
         *    to invoke methods on an object.
         *    
         * Some methods take no arguments, but we still have parenthesis.
         * Some methods take one or more arguements.
         *   Multiple arguements are seperated by commas.
         *   
         * Mutator methods modify the state (value of attributes) of the object.
         * 
         */
        crush.penDown();
        crush.forward(25);
        crush.setPenColor(Color.RED);
        crush.forward(25);
        
        /*
         * Accesor methods return the value of an attribute of the object
         *   The state of the object does not change.
         *   
         *   getPenWidth is an accessor method.
         */
        
        int penWidth = crush.getPenWidth();
        
    }
}


  
